<?php
include 'connection.php';
include 'header.php';
?>





    <!--====Courses Section
    ====================================-->
    <section id="courses-section" class="popular-courses-area bg-gray s-pd2">
    <div class="container">


<h1>Welcome to Admin</h1>

    </div><!--/.container-->
  </section><!--/#courses-section-->






<?php
include 'footer.php';
 ?>
